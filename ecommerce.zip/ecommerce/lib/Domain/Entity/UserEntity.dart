/// name : "Ahmed Abd Al-Muti"
/// email : "adham42326@gmail.com"
/// role : "user"

class UserEntity {
  UserEntity({
      this.name, 
      this.email, 
      });

  String? name;
  String? email;


}