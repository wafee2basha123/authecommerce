class ApiConstats{
  static const  String BasrUrl = 'ecommerce.routemisr.com';
}
class ApiEndPoint{
  static const String RegisterApi = '/api/v1/auth/signup';
}